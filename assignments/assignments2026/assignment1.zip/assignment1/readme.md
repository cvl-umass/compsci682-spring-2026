Details about this assignment can be found [on the course webpage](https://cvl-umass.github.io/compsci682-spring-2026/assignments/assignments2026/assignment1/), under Assignment #1 of Spring 2026.

